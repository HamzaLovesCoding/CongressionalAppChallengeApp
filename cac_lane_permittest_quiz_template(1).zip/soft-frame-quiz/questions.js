/* Supplied PDF question bank. Answer keys are retained; this is not an official DMV bank. */
window.CA_PERMIT_BANK = {
  "title": "California · Practice",
  "target": 0.8,
  "topics": {
    "signs": "Signs & road markings",
    "safe": "Safe driving & speed",
    "lanes": "Turns, lanes & passing",
    "yield": "Right-of-way & pedestrians",
    "parking": "Parking & curbs",
    "duties": "Driver responsibilities"
  },
  "questions": [
    {
      "id": "ca-001",
      "prompt": "What is the recommended minimum following distance behind a vehicle?",
      "choices": [
        {
          "id": "a",
          "text": "50 feet"
        },
        {
          "id": "b",
          "text": "one car length for every 10 mph"
        },
        {
          "id": "c",
          "text": "3 seconds"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "safe",
      "conceptId": "following-distance",
      "image": null,
      "sourcePage": 1
    },
    {
      "id": "ca-002",
      "prompt": "What does this sign mean?",
      "choices": [
        {
          "id": "a",
          "text": "There are no intersections ahead for a long time."
        },
        {
          "id": "b",
          "text": "You are approaching crossroads ahead."
        },
        {
          "id": "c",
          "text": "Turn right soon."
        }
      ],
      "correctChoiceId": "b",
      "topicId": "signs",
      "conceptId": "crossroads",
      "image": {
        "src": "assets/sign-2.svg",
        "alt": "Yellow diamond with a black cross-shaped symbol."
      },
      "sourcePage": 1
    },
    {
      "id": "ca-003",
      "prompt": "A sign depicting a bicycle with two arrows above it indicates:",
      "choices": [
        {
          "id": "a",
          "text": "bicycle crossing"
        },
        {
          "id": "b",
          "text": "bicycles only"
        },
        {
          "id": "c",
          "text": "shared lane for bicycles and vehicles"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "signs",
      "conceptId": "shared-lane",
      "image": null,
      "sourcePage": 1
    },
    {
      "id": "ca-004",
      "prompt": "Who is required to wear a seatbelt in a vehicle in California?",
      "choices": [
        {
          "id": "a",
          "text": "every occupant of the vehicle"
        },
        {
          "id": "b",
          "text": "only children under the age of 12"
        },
        {
          "id": "c",
          "text": "only the driver and front seat passenger"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "seatbelts",
      "image": null,
      "sourcePage": 2
    },
    {
      "id": "ca-005",
      "prompt": "What action should drivers take when their vehicle is being passed?",
      "choices": [
        {
          "id": "a",
          "text": "maintain lane position and speed"
        },
        {
          "id": "b",
          "text": "slow down suddenly to make room"
        },
        {
          "id": "c",
          "text": "speed up to make the pass more difficult for the other vehicle"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "lanes",
      "conceptId": "being-passed",
      "image": null,
      "sourcePage": 2
    },
    {
      "id": "ca-006",
      "prompt": "In a roundabout, drivers must:",
      "choices": [
        {
          "id": "a",
          "text": "stop inside the roundabout to allow other vehicles to enter"
        },
        {
          "id": "b",
          "text": "travel in a counter-clockwise direction and yield to traffic already in the roundabout"
        },
        {
          "id": "c",
          "text": "accelerate to merge quickly with the roundabout traffic"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "yield",
      "conceptId": "roundabouts",
      "image": null,
      "sourcePage": 2
    },
    {
      "id": "ca-007",
      "prompt": "What do two sets of double yellow lines that are spaced two feet or more apart indicate?",
      "choices": [
        {
          "id": "a",
          "text": "lanes of traffic moving in the opposite direction"
        },
        {
          "id": "b",
          "text": "a barrier not to be crossed"
        },
        {
          "id": "c",
          "text": "carpool/high-Occupancy (HOV) lane"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "signs",
      "conceptId": "yellow-barrier",
      "image": null,
      "sourcePage": 2
    },
    {
      "id": "ca-008",
      "prompt": "If someone is seriously injured while a driver intentionally tries to evade police, what could the consequence be?",
      "choices": [
        {
          "id": "a",
          "text": "suspension of license for one year"
        },
        {
          "id": "b",
          "text": "$250 fine and probation"
        },
        {
          "id": "c",
          "text": "sentence of up to 7 years in a state prison"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "duties",
      "conceptId": "police-evasion",
      "image": null,
      "sourcePage": 3
    },
    {
      "id": "ca-009",
      "prompt": "What lights should you turn on if dust or smoke is limiting your visibility?",
      "choices": [
        {
          "id": "a",
          "text": "Use your headlights to help you see and be seen."
        },
        {
          "id": "b",
          "text": "Use your parking lights only."
        },
        {
          "id": "c",
          "text": "Turn on emergency flashers and stop in place."
        }
      ],
      "correctChoiceId": "a",
      "topicId": "safe",
      "conceptId": "visibility",
      "image": null,
      "sourcePage": 3
    },
    {
      "id": "ca-010",
      "prompt": "Where should you position your vehicle when making a left turn from a one-way street to another one-way street?",
      "choices": [
        {
          "id": "a",
          "text": "from any available traffic lane"
        },
        {
          "id": "b",
          "text": "from the lane closest to the left curb"
        },
        {
          "id": "c",
          "text": "from the far-right lane"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "lanes",
      "conceptId": "one-way-turns",
      "image": null,
      "sourcePage": 3
    },
    {
      "id": "ca-011",
      "prompt": "When is it legal to drive off the paved roadway to pass another vehicle?",
      "choices": [
        {
          "id": "a",
          "text": "under no circumstances"
        },
        {
          "id": "b",
          "text": "if the shoulder is wide enough to accommodate your vehicle"
        },
        {
          "id": "c",
          "text": "if the vehicle ahead of you is turning left"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "lanes",
      "conceptId": "paved-passing",
      "image": null,
      "sourcePage": 3
    },
    {
      "id": "ca-012",
      "prompt": "If you refuse a blood or urine test requested by law enforcement, what can the DMV do?",
      "choices": [
        {
          "id": "a",
          "text": "suspend or revoke your driving privilege"
        },
        {
          "id": "b",
          "text": "nothing, as test refusal is your right"
        },
        {
          "id": "c",
          "text": "only issue a warning"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "test-refusal",
      "image": null,
      "sourcePage": 4
    },
    {
      "id": "ca-013",
      "prompt": "What vehicles are covered by a non-commercial Class C driver's license?",
      "choices": [
        {
          "id": "a",
          "text": "standard passenger cars"
        },
        {
          "id": "b",
          "text": "commercial vehicles"
        },
        {
          "id": "c",
          "text": "buses"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "license-class",
      "image": null,
      "sourcePage": 4
    },
    {
      "id": "ca-014",
      "prompt": "What does a white-painted curb mean?",
      "choices": [
        {
          "id": "a",
          "text": "loading or unloading passengers only"
        },
        {
          "id": "b",
          "text": "no stopping, standing, or parking"
        },
        {
          "id": "c",
          "text": "loading zone for freight only"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "parking",
      "conceptId": "white-curbs",
      "image": null,
      "sourcePage": 4
    },
    {
      "id": "ca-015",
      "prompt": "It is against the law to leave a child six years old or younger unattended in a vehicle unless:",
      "choices": [
        {
          "id": "a",
          "text": "They are under the supervision of a person who is at least 12 years old."
        },
        {
          "id": "b",
          "text": "They are sleeping."
        },
        {
          "id": "c",
          "text": "The windows are slightly open."
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "child-supervision",
      "image": null,
      "sourcePage": 5
    },
    {
      "id": "ca-016",
      "prompt": "If you're involved in a collision without proper insurance coverage, your driving privilege can be suspended for up to how many years?",
      "choices": [
        {
          "id": "a",
          "text": "3 years"
        },
        {
          "id": "b",
          "text": "1 year"
        },
        {
          "id": "c",
          "text": "4 years"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "duties",
      "conceptId": "insurance",
      "image": null,
      "sourcePage": 5
    },
    {
      "id": "ca-017",
      "prompt": "When passing a bicyclist in the travel lane, what should you do if you cannot change lanes?",
      "choices": [
        {
          "id": "a",
          "text": "pass with at least three feet clearance when safe"
        },
        {
          "id": "b",
          "text": "honk to alert the bicyclist of your presence"
        },
        {
          "id": "c",
          "text": "speed past the bicyclist quickly to minimize time beside them"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "lanes",
      "conceptId": "bicycle-clearance",
      "image": null,
      "sourcePage": 5
    },
    {
      "id": "ca-018",
      "prompt": "What does this sign mean?",
      "choices": [
        {
          "id": "a",
          "text": "This is a two-way street."
        },
        {
          "id": "b",
          "text": "The speed limit will soon increase."
        },
        {
          "id": "c",
          "text": "This is a one-way street."
        }
      ],
      "correctChoiceId": "a",
      "topicId": "signs",
      "conceptId": "two-way",
      "image": {
        "src": "assets/sign-18.svg",
        "alt": "Yellow diamond with two vertical black arrows pointing in opposite directions."
      },
      "sourcePage": 5
    },
    {
      "id": "ca-019",
      "prompt": "When driving near a large vehicle or truck, why is it important not to follow too closely?",
      "choices": [
        {
          "id": "a",
          "text": "Large vehicles can stop more quickly than cars."
        },
        {
          "id": "b",
          "text": "Large vehicles have large blind spots and require more distance to stop safely."
        },
        {
          "id": "c",
          "text": "Tailgating a large vehicle improves fuel efficiency."
        }
      ],
      "correctChoiceId": "b",
      "topicId": "safe",
      "conceptId": "truck-blind-spots",
      "image": null,
      "sourcePage": 6
    },
    {
      "id": "ca-020",
      "prompt": "When scanning your surroundings, how far ahead should you be looking?",
      "choices": [
        {
          "id": "a",
          "text": "immediately in front of your vehicle only"
        },
        {
          "id": "b",
          "text": "only to the sides of your vehicle"
        },
        {
          "id": "c",
          "text": "at least 10 seconds ahead of your vehicle"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "safe",
      "conceptId": "scanning",
      "image": null,
      "sourcePage": 6
    },
    {
      "id": "ca-021",
      "prompt": "When approaching a pedestrian using a guide dog or white cane, which of the following is true?",
      "choices": [
        {
          "id": "a",
          "text": "Pedestrians using guide dogs or white canes have the right-of-way at all times."
        },
        {
          "id": "b",
          "text": "It's safe to stop in the middle of a crosswalk."
        },
        {
          "id": "c",
          "text": "You should honk to alert the pedestrian of your presence."
        }
      ],
      "correctChoiceId": "a",
      "topicId": "yield",
      "conceptId": "blind-pedestrians",
      "image": null,
      "sourcePage": 6
    },
    {
      "id": "ca-022",
      "prompt": "What is the law on using handheld devices while driving in California?",
      "choices": [
        {
          "id": "a",
          "text": "Handheld devices are banned for all drivers."
        },
        {
          "id": "b",
          "text": "Texting is allowed for drivers over the age of 25."
        },
        {
          "id": "c",
          "text": "Handheld devices are banned for teen drivers only."
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "phone-use",
      "image": null,
      "sourcePage": 7
    },
    {
      "id": "ca-023",
      "prompt": "What is a U-turn?",
      "choices": [
        {
          "id": "a",
          "text": "changing lanes in an intersection"
        },
        {
          "id": "b",
          "text": "making three consecutive right turns"
        },
        {
          "id": "c",
          "text": "turning your vehicle around to head in the opposite direction"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "lanes",
      "conceptId": "u-turn",
      "image": null,
      "sourcePage": 7
    },
    {
      "id": "ca-024",
      "prompt": "If a driver is involved in a collision causing death or injury, they must report the collision to:",
      "choices": [
        {
          "id": "a",
          "text": "their insurance company"
        },
        {
          "id": "b",
          "text": "both DMV and the local police department"
        },
        {
          "id": "c",
          "text": "the local police department"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "duties",
      "conceptId": "collision-reporting",
      "image": null,
      "sourcePage": 7
    },
    {
      "id": "ca-025",
      "prompt": "When must you follow the instructions given by a school crossing guard?",
      "choices": [
        {
          "id": "a",
          "text": "only when children are crossing"
        },
        {
          "id": "b",
          "text": "only during school hours"
        },
        {
          "id": "c",
          "text": "at all times when they are directing traffic"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "yield",
      "conceptId": "crossing-guards",
      "image": null,
      "sourcePage": 7
    },
    {
      "id": "ca-026",
      "prompt": "Under what circumstances must you submit a California SR-1 accident report form to the DMV?",
      "choices": [
        {
          "id": "a",
          "text": "when you update your vehicle insurance provider"
        },
        {
          "id": "b",
          "text": "if you are in an accident that causes injury or death"
        },
        {
          "id": "c",
          "text": "when your registration renewal is overdue"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "duties",
      "conceptId": "collision-reporting",
      "image": null,
      "sourcePage": 8
    },
    {
      "id": "ca-027",
      "prompt": "How far before a turn or lane change must you signal your intention?",
      "choices": [
        {
          "id": "a",
          "text": "at least 100 feet before the turn"
        },
        {
          "id": "b",
          "text": "at least 300 feet before the turn"
        },
        {
          "id": "c",
          "text": "at least 50 feet before the turn"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "lanes",
      "conceptId": "signaling",
      "image": null,
      "sourcePage": 8
    },
    {
      "id": "ca-028",
      "prompt": "When are you allowed to drive in a bicycle lane in California?",
      "choices": [
        {
          "id": "a",
          "text": "at any time when driving slower than 25 mph"
        },
        {
          "id": "b",
          "text": "on one-way streets"
        },
        {
          "id": "c",
          "text": "up to 200 feet before making a right turn"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "lanes",
      "conceptId": "bicycle-lane-turn",
      "image": null,
      "sourcePage": 8
    },
    {
      "id": "ca-029",
      "prompt": "For which of these people would it be legal to operate a vehicle with a blood alcohol concentration (BAC) of 0.04?",
      "choices": [
        {
          "id": "a",
          "text": "persons under 21 years of age"
        },
        {
          "id": "b",
          "text": "persons 21 years of age or older"
        },
        {
          "id": "c",
          "text": "persons on a DUI probation"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "duties",
      "conceptId": "alcohol",
      "image": null,
      "sourcePage": 8
    },
    {
      "id": "ca-030",
      "prompt": "Which statement accurately describes large commercial trucks?",
      "choices": [
        {
          "id": "a",
          "text": "Their braking systems are more responsive than standard cars."
        },
        {
          "id": "b",
          "text": "They have extensive blind spots, which can obscure other vehicles from their view."
        },
        {
          "id": "c",
          "text": "Their wide turning radius makes them ideal for city driving."
        }
      ],
      "correctChoiceId": "b",
      "topicId": "safe",
      "conceptId": "truck-blind-spots",
      "image": null,
      "sourcePage": 9
    },
    {
      "id": "ca-031",
      "prompt": "How many days do you have to report a collision causing more than $1,000 in damage to DMV?",
      "choices": [
        {
          "id": "a",
          "text": "10 days"
        },
        {
          "id": "b",
          "text": "21 days"
        },
        {
          "id": "c",
          "text": "7 days"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "collision-reporting",
      "image": null,
      "sourcePage": 9
    },
    {
      "id": "ca-032",
      "prompt": "What is the speed limit when driving within 500 feet of a school while children are outside?",
      "choices": [
        {
          "id": "a",
          "text": "35 mph"
        },
        {
          "id": "b",
          "text": "25 mph"
        },
        {
          "id": "c",
          "text": "15 mph"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "safe",
      "conceptId": "school-speed",
      "image": null,
      "sourcePage": 9
    },
    {
      "id": "ca-033",
      "prompt": "When is it legal to park in a crosshatched or diagonally striped space next to a blue curb?",
      "choices": [
        {
          "id": "a",
          "text": "Only when no designated disabled spaces are available."
        },
        {
          "id": "b",
          "text": "If the crosshatched area is marked for loading."
        },
        {
          "id": "c",
          "text": "Never — these areas are off-limits for parking at all times."
        }
      ],
      "correctChoiceId": "c",
      "topicId": "parking",
      "conceptId": "accessible-parking",
      "image": null,
      "sourcePage": 10
    },
    {
      "id": "ca-034",
      "prompt": "You're approaching an uncontrolled railroad crossing. If you're within 100 feet and have limited visibility (less than 400 feet in both directions), what's the maximum safe speed?",
      "choices": [
        {
          "id": "a",
          "text": "15 mph"
        },
        {
          "id": "b",
          "text": "10 mph"
        },
        {
          "id": "c",
          "text": "25 mph"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "safe",
      "conceptId": "railroad-speed",
      "image": null,
      "sourcePage": 10
    },
    {
      "id": "ca-035",
      "prompt": "What is the correct response if your vehicleʼs wheels drift off the pavement?",
      "choices": [
        {
          "id": "a",
          "text": "Accelerate quickly to rejoin traffic."
        },
        {
          "id": "b",
          "text": "Brake hard and steer back onto the pavement immediately."
        },
        {
          "id": "c",
          "text": "Grip the steering wheel firmly, remove your foot from the accelerator, and brake gently before steering back onto the pavement."
        }
      ],
      "correctChoiceId": "c",
      "topicId": "safe",
      "conceptId": "off-pavement",
      "image": null,
      "sourcePage": 10
    },
    {
      "id": "ca-036",
      "prompt": "How should you react to an emergency vehicle displaying flashing lights and sounding a siren?",
      "choices": [
        {
          "id": "a",
          "text": "speed up to clear traffic for it"
        },
        {
          "id": "b",
          "text": "move over to allow a clear path and stop if necessary"
        },
        {
          "id": "c",
          "text": "follow closely to get through traffic"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "yield",
      "conceptId": "emergency-vehicles",
      "image": null,
      "sourcePage": 10
    },
    {
      "id": "ca-037",
      "prompt": "When is it okay to drive in a bicycle lane?",
      "choices": [
        {
          "id": "a",
          "text": "when turning right within 200 feet of an intersection"
        },
        {
          "id": "b",
          "text": "when the bicycle lane is unoccupied"
        },
        {
          "id": "c",
          "text": "at all times, regardless of the situation."
        }
      ],
      "correctChoiceId": "a",
      "topicId": "lanes",
      "conceptId": "bicycle-lane-turn",
      "image": null,
      "sourcePage": 11
    },
    {
      "id": "ca-038",
      "prompt": "Under NO circumstances are you allowed to:",
      "choices": [
        {
          "id": "a",
          "text": "pass a vehicle on the left"
        },
        {
          "id": "b",
          "text": "leave the roadway to pass another car"
        },
        {
          "id": "c",
          "text": "leave the roadway to avoid a serious collision"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "lanes",
      "conceptId": "paved-passing",
      "image": null,
      "sourcePage": 11
    },
    {
      "id": "ca-039",
      "prompt": "Not stopping for a school bus that is unloading children can result in:",
      "choices": [
        {
          "id": "a",
          "text": "a warning for the first offense"
        },
        {
          "id": "b",
          "text": "a fine up to $1,000 and possible suspension of driving privilege"
        },
        {
          "id": "c",
          "text": "having your license revoked"
        }
      ],
      "correctChoiceId": "b",
      "topicId": "yield",
      "conceptId": "school-bus",
      "image": null,
      "sourcePage": 11
    },
    {
      "id": "ca-040",
      "prompt": "After becoming a resident or getting a job in California, you have how many days to register your out-of-state vehicle?",
      "choices": [
        {
          "id": "a",
          "text": "30 days"
        },
        {
          "id": "b",
          "text": "10 days"
        },
        {
          "id": "c",
          "text": "20 days"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "duties",
      "conceptId": "registration",
      "image": null,
      "sourcePage": 12
    },
    {
      "id": "ca-041",
      "prompt": "A left turn on a red light is:",
      "choices": [
        {
          "id": "a",
          "text": "never allowed"
        },
        {
          "id": "b",
          "text": "always allowed if turning onto a one-way street"
        },
        {
          "id": "c",
          "text": "only allowed if turning from one one-way street onto another one-way street"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "lanes",
      "conceptId": "red-light-turn",
      "image": null,
      "sourcePage": 12
    },
    {
      "id": "ca-042",
      "prompt": "When are fines for traffic violations in a work zone doubled?",
      "choices": [
        {
          "id": "a",
          "text": "only during peak hours"
        },
        {
          "id": "b",
          "text": "if the violation results in a traffic jam"
        },
        {
          "id": "c",
          "text": "when workers are present"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "duties",
      "conceptId": "work-zone",
      "image": null,
      "sourcePage": 12
    },
    {
      "id": "ca-043",
      "prompt": "What is the correct response when someone in a motorized wheelchair is crossing in front of you at an intersection?",
      "choices": [
        {
          "id": "a",
          "text": "Carefully drive around them if thereʼs enough room."
        },
        {
          "id": "b",
          "text": "Wait behind the crosswalk until the person has fully cleared your vehicleʼs path."
        },
        {
          "id": "c",
          "text": "Proceed slowly as long as the person is not directly in your lane."
        }
      ],
      "correctChoiceId": "b",
      "topicId": "yield",
      "conceptId": "wheelchair-pedestrians",
      "image": null,
      "sourcePage": 12
    },
    {
      "id": "ca-044",
      "prompt": "Under what condition is it necessary to file a Report of Traffic Accident Occurring in California (SR-1)?",
      "choices": [
        {
          "id": "a",
          "text": "You were involved in a collision with an injury."
        },
        {
          "id": "b",
          "text": "Your driver's license has expired."
        },
        {
          "id": "c",
          "text": "after a routine vehicle inspection"
        }
      ],
      "correctChoiceId": "a",
      "topicId": "duties",
      "conceptId": "collision-reporting",
      "image": null,
      "sourcePage": 13
    },
    {
      "id": "ca-045",
      "prompt": "What does a diamond-shaped sign on a truck indicate?",
      "choices": [
        {
          "id": "a",
          "text": "The truck has priority over other vehicles."
        },
        {
          "id": "b",
          "text": "The truck is oversized."
        },
        {
          "id": "c",
          "text": "The truck is carrying hazardous materials."
        }
      ],
      "correctChoiceId": "c",
      "topicId": "signs",
      "conceptId": "hazardous-materials",
      "image": null,
      "sourcePage": 13
    },
    {
      "id": "ca-046",
      "prompt": "When is it legal to pass another vehicle on the right?",
      "choices": [
        {
          "id": "a",
          "text": "when driving on a narrow two-lane road"
        },
        {
          "id": "b",
          "text": "when you're in a hurry"
        },
        {
          "id": "c",
          "text": "when the other vehicle is turning left and there is space to safely pass"
        }
      ],
      "correctChoiceId": "c",
      "topicId": "lanes",
      "conceptId": "right-passing",
      "image": null,
      "sourcePage": 13
    }
  ]
};
