/* Dependency-free, embeddable quiz. No answer key or missed-question list is rendered. */
(() => {
  const base = new URL('.', document.currentScript.src);
  const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function validate(bank) {
    if (!Array.isArray(bank.questions) || !bank.questions.length) throw new Error('Supply at least one question.');
    if (!Number.isFinite(bank.target) || bank.target < 0 || bank.target > 1) throw new Error('Target must be between 0 and 1.');
    const ids = new Set();
    for (const q of bank.questions) {
      if (!q.id || ids.has(q.id) || !q.prompt || !q.topicId || !q.conceptId) throw new Error('Questions need unique IDs, prompts, topics, and concepts.');
      ids.add(q.id);
      if (!Array.isArray(q.choices) || q.choices.length < 2 || q.choices.some(c => !c.id || !c.text) || new Set(q.choices.map(c => c.id)).size !== q.choices.length || !q.choices.some(c => c.id === q.correctChoiceId)) throw new Error(`Invalid choices in ${q.id}.`);
      if (q.image && (!q.image.src || !q.image.alt)) throw new Error(`Image needs a source and description in ${q.id}.`);
    }
  }

  function summarize(questions, responses, target, labels) {
    const correct = responses.filter(Boolean).length;
    const groups = new Map();
    questions.forEach((q, i) => {
      if (!groups.has(q.topicId)) groups.set(q.topicId, new Map());
      const concepts = groups.get(q.topicId);
      const tally = concepts.get(q.conceptId) || {correct:0, total:0};
      tally.total++; tally.correct += Number(responses[i]);
      concepts.set(q.conceptId, tally);
    });
    const topics = [...groups].map(([id, concepts]) => {
      // Equal concept weights prevent duplicate questions inflating topic evidence.
      const accuracy = [...concepts.values()].reduce((sum, c) => sum + c.correct / c.total, 0) / concepts.size;
      return {id, label:labels[id] || id, concepts:concepts.size, accuracy,
        status:concepts.size < 3 ? 'limited' : accuracy < target ? 'review' : 'on-track'};
    }).sort((a,b) => a.accuracy - b.accuracy);
    return {correct, total:questions.length, percentage:Math.round(correct / questions.length * 100), target, meetsTarget:correct / questions.length >= target, topics};
  }

  class PermitQuiz extends HTMLElement {
    #bank; #index = 0; #selected = null; #phase = 'answer'; #responses = []; #callback; #imageReady = true;
    constructor() {
      super();
      const root = this.attachShadow({mode:'open'});
      const link = document.createElement('link');
      link.rel = 'stylesheet'; link.href = new URL('quiz.css', base).href;
      root.append(link, document.createElement('main'));
      root.querySelector('main').className = 'shell';
    }
    configure({questions, title = 'Practice quiz', topics = {}, target = .8, onComplete} = {}) {
      const bank = structuredClone({questions, title, topics, target});
      validate(bank);
      this.#bank = bank;
      this.#callback = typeof onComplete === 'function' ? onComplete : null;
      this.#restart(false);
    }
    #restart(focus = true) {
      this.#index = 0; this.#selected = null; this.#phase = 'answer'; this.#responses = [];
      this.#render(focus);
    }
    #render(focus = false) {
      const main = this.shadowRoot.querySelector('main');
      const bank = this.#bank;
      if (this.#phase === 'results') {
        const result = summarize(bank.questions, this.#responses, bank.target, bank.topics);
        const review = result.topics.filter(t => t.status === 'review');
        const limited = result.topics.filter(t => t.status === 'limited');
        main.innerHTML = `<header class="top"><span>${escape(bank.title)}</span><span>Complete</span></header>
          <section class="results"><p class="eyebrow">Practice complete</p><h1 tabindex="-1">Your results</h1>
          <p class="score">${result.percentage}%</p><p class="summary">${result.correct} of ${result.total} correct · ${result.meetsTarget ? 'Target reached' : 'Below target'}</p>
          <h2>Areas to improve</h2>${review.length ? `<ul class="topics">${review.map(t => `<li>${escape(t.label)}</li>`).join('')}</ul>` : '<p class="detail">No review areas identified with enough evidence.</p>'}
          ${limited.length ? `<h2>More practice to assess</h2><ul class="topics">${limited.map(t => `<li>${escape(t.label)}</li>`).join('')}</ul><p class="detail">Too few different concepts were tested in these areas.</p>` : ''}
          </section><footer class="bottom"><button class="action" type="button">Start again</button><p class="caption">Practice target: ${Math.round(bank.target * 100)}%</p></footer>`;
        main.querySelector('button').onclick = () => this.#restart();
        if (focus) main.querySelector('h1').focus();
        // Only aggregate results leave the component.
        this.dispatchEvent(new CustomEvent('quiz-complete', {detail:structuredClone(result), bubbles:true, composed:true}));
        this.#callback?.(structuredClone(result));
        return;
      }
      const q = bank.questions[this.#index];
      this.#imageReady = !q.image;
      main.innerHTML = `<header class="top"><span>${escape(bank.title)}</span><span class="count">${this.#index + 1} / ${bank.questions.length}</span></header>
        <div class="progress" role="progressbar" aria-label="Questions completed" aria-valuemin="0" aria-valuemax="${bank.questions.length}" aria-valuenow="${this.#index}"><span style="width:${this.#index / bank.questions.length * 100}%"></span></div>
        <section><p class="eyebrow">Question ${String(this.#index + 1).padStart(2,'0')}</p><h1 id="question" tabindex="-1">${escape(q.prompt)}</h1>
        ${q.image ? `<img class="sign" width="132" height="132" alt="${escape(q.image.alt)}">` : ''}
        <fieldset aria-labelledby="question">${q.choices.map(c => `<label class="option"><input type="radio" name="answer" value="${escape(c.id)}"><span>${escape(c.text)}</span></label>`).join('')}</fieldset></section>
        <footer class="bottom"><p class="feedback" role="status" aria-live="polite" aria-atomic="true"></p><button class="action" type="button" disabled>Submit answer</button><p class="caption">Choose one answer</p></footer>`;
      const action = main.querySelector('button');
      const feedback = main.querySelector('.feedback');
      main.querySelector('fieldset').onchange = event => {
        if (this.#phase !== 'answer') return;
        this.#selected = event.target.value;
        action.disabled = !this.#imageReady;
      };
      if (q.image) {
        const image = main.querySelector('img');
        image.onload = () => {this.#imageReady = true; action.disabled = this.#selected === null;};
        image.onerror = () => {this.#imageReady = false; action.disabled = true; feedback.textContent = 'The sign could not load. Reload to try again.'; feedback.classList.add('bad');};
        image.src = new URL(q.image.src, base).href;
      }
      action.onclick = () => {
        if (this.#phase === 'answer') {
          if (this.#selected === null || !this.#imageReady) return;
          const correct = this.#selected === q.correctChoiceId;
          this.#responses.push(correct);
          this.#phase = 'feedback';
          main.querySelectorAll('input').forEach(input => input.disabled = true);
          feedback.textContent = correct ? '✓ Correct' : '× Incorrect';
          feedback.classList.add(correct ? 'good' : 'bad');
          action.textContent = this.#index === bank.questions.length - 1 ? 'View results' : 'Next question';
          main.querySelector('.caption').textContent = 'Answer recorded';
          const progress = main.querySelector('.progress');
          progress.setAttribute('aria-valuenow', this.#index + 1);
          progress.firstElementChild.style.width = `${(this.#index + 1) / bank.questions.length * 100}%`;
        } else if (this.#phase === 'feedback') {
          this.#index++; this.#selected = null;
          this.#phase = this.#index === bank.questions.length ? 'results' : 'answer';
          this.#render(true);
        }
      };
      if (focus) main.querySelector('h1').focus();
    }
  }
  if (!customElements.get('permit-quiz')) customElements.define('permit-quiz', PermitQuiz);
})();
