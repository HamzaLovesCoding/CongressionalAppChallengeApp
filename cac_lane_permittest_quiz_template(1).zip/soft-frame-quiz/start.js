const quiz = document.querySelector('permit-quiz');
quiz.configure(window.CA_PERMIT_BANK);
