# Soft frame quiz

Open `index.html` directly in a browser. No install, build step, internet connection, or server is required. All 46 questions are included. On mobile, serve this folder through any static host or integrate the component into your project.

## Embed

Copy `quiz.js`, `quiz.css`, `questions.js`, and `assets/` together into your project. Load the two scripts in order, then configure the element:

```html
<script src="/quiz/questions.js"></script>
<script src="/quiz/quiz.js"></script>
<permit-quiz id="permit"></permit-quiz>
<script>
  document.getElementById('permit').configure({
    ...window.CA_PERMIT_BANK,
    onComplete: result => console.log(result)
  });
</script>
```

The Shadow DOM isolates styling. `quiz.css` and image paths resolve relative to `quiz.js`; absolute image URLs also work. Supply another bank to reuse the same UI. Multiple quiz instances maintain separate state. Configuring again starts a fresh attempt. There is no saved attempt on reload.

Public options: `questions`, `topics` (ID-to-label map), `title`, `target` (0–1, default 0.8), and optional `onComplete`. The bubbling `quiz-complete` event provides the same aggregate result. Neither API returns individual answers or missed-question IDs. Host code should treat the bank as trusted application data.

Customize CSS variables on the element, for example:

```css
permit-quiz { --quiz-ink: #242824; --quiz-line: #d5d9d3; }
```

## Behavior

Select a radio answer, submit, receive Correct or Incorrect, then advance explicitly. Submitted answers cannot be changed. No correct-answer highlighting or explanations. Results show overall score and broad topic guidance. The raw score fraction determines whether the practice target was reached; the displayed percentage is rounded. All 46 questions must be answered before scoring is shown.

For topic guidance, each distinct concept has equal weight, so repeated variants do not dominate. Topics below 80% with at least three tested concepts appear in Areas to improve. Topics with fewer than three concepts appear under More practice to assess. This is a transparent practice heuristic, not a validated readiness prediction. A new attempt uses the same supplied order.

The local answer key is hidden from the interface, not protected from source inspection. Server-side grading is needed if key confidentiality is a requirement.

## Source and artwork

Question text and answer keys come from the supplied `CAC Permit Test Final Quiz Bank.pdf`. All 46 choice keys were checked against its explicit answer text. Extraction artifacts (broken `ft` ligatures, stray markdown, line wrapping) were cleaned. Source page, topic, and concept IDs live in `questions.js`. This implementation preserves the supplied answers; it does not claim a current legal-content audit.

The PDF has text placeholders for questions 2 and 18. `assets/sign-2.svg` and `assets/sign-18.svg` are newly drawn replacement illustrations of the standard crossroad and two-way warning symbols, respectively—not images recovered from the PDF. Descriptive alt text describes the visible geometry without naming the tested meaning. Replace these if you have the original artwork.

Symbol reference: [California DMV handbook sign chart](https://www.dmv.ca.gov/portal/uploads/2020/06/dl600.pdf). Practice target reference: [DMV instruction permits](https://www.dmv.ca.gov/portal/driver-licenses-identification-cards/learners-permits/).

Files: `index.html` is the standalone host; `start.js` initializes it; `quiz.js` is the reusable component; `quiz.css` holds its styles; `questions.js` is the bank; `assets/` contains the two local SVGs. No third-party runtime dependencies.
